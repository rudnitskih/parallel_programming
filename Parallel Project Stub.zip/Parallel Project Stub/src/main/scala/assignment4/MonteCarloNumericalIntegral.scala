package assignment4

import scala.util.Random

import org.scalameter._
import ua.edu.ucu.cs.parallel._

object MonteCarloNumericalIntegral {

  def getRandomBeetwen(start: Double, end: Double): Double = start + (new Random().nextDouble() * (end - start));

  def integral(func: Double => Double, start: Double, end: Double, numberPoints: Int): Double = 
    (end - start) / numberPoints * sumValues(func, start, end, numberPoints)
  
  def sumValues(func: Double => Double, start: Double, end: Double, numberPoints: Int): Double = {
    def it(currentSquare: Double, pointsGenerated: Int): Double = {
      if (pointsGenerated < numberPoints) {
        it(
          currentSquare + func(getRandomBeetwen(start, end)),
          pointsGenerated + 1)
      } else {
        currentSquare
      }
    }

    it(0, 0)
  }

  def integralPar(func: Double => Double, start: Double, end: Double, numberPoints: Int): Double = {
    val (res1, res2, res3, res4) = parallel(
      integral(func, start, end, numberPoints / 4),
      integral(func, start, end, numberPoints / 4),
      integral(func, start, end, numberPoints / 4),
      integral(func, start, end, numberPoints / 4))

    (res1 + res2 + res3 + res4) / 4
  }

  def main(args: Array[String]): Unit = {
    val totalNumberOfPoints = 1000000
    val start = 0
    val end = 2

    def func(x: Double): Double = Math.cos(x)

    val standardConfig = config(
      Key.exec.minWarmupRuns -> 10,
      Key.exec.maxWarmupRuns -> 100,
      Key.exec.benchRuns -> 50,
      Key.verbose -> true) withWarmer (new Warmer.Default)

    val seqtime = standardConfig measure {
      integral(func, start, end, totalNumberOfPoints)
    }

    val partime = standardConfig measure {
      integralPar(func, start, end, totalNumberOfPoints)
    }

    println(s"sequntial time $seqtime")
    println(s"parallel time $partime ms")
    println(s"speedup ${seqtime.value / partime.value}")

    val seqResult = integral(func, start, end, totalNumberOfPoints)
    val parResult = integralPar(func, start, end, totalNumberOfPoints)

    println(s"seqResult $seqResult")
    println(s"parResult $parResult")
  }
}